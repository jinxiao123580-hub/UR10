"""Offline relaxed-return-screen audit. Never installs or enables models."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from calibrate_pen_tcp import save
sys.path.insert(0,'/home/jx/UR10/scripts')
from calibrate_ft_gravity import fit_gravity,skew,GRAVITY


def load_sample(row,home=False):
    d=json.loads(Path(row['out']).read_text())
    pose=d['before_tcp_at_force_window_m_rad'] if home else d['after_tcp_m_rad']
    wrench=d['raw_before']['mean'] if home else d['raw_after']['mean']
    return {'rotation_base_tool':Rotation.from_rotvec(pose[3:]).as_matrix(),
            'wrench':np.asarray(wrench),'source':row['out'],'is_home':home}


def metrics(samples,model):
    rs=np.asarray(model['rotation_sensor_from_tool']);c=np.asarray(model['com_sensor_m'])
    residual=[]
    for s in samples:
        f=model['mass_kg']*rs@s['rotation_base_tool'].T@np.array([0,0,-GRAVITY])
        prediction=np.r_[f+model['force_bias_n'],np.cross(c,f)+model['torque_bias_nm']]
        residual.append(s['wrench']-prediction)
    e=np.asarray(residual)
    return {'count':len(samples),'force_component_rms_n':float(np.sqrt(np.mean(e[:,:3]**2))),
            'force_component_max_abs_n':float(np.abs(e[:,:3]).max()),
            'force_vector_max_n':float(np.linalg.norm(e[:,:3],axis=1).max()),
            'torque_component_rms_nm':float(np.sqrt(np.mean(e[:,3:]**2))),
            'torque_vector_max_nm':float(np.linalg.norm(e[:,3:],axis=1).max()),
            'residuals_n_nm':e.tolist()}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--session',type=Path,required=True)
    p.add_argument('--extra-validation',type=Path,nargs='*',default=[])
    args=p.parse_args();d=json.loads(args.session.read_text());train=[];held=[]
    for i,row in enumerate(d['pairs']):
        if not row['pose_return_passed'] or row['return_force_norm_n']>.5 or row['return_torque_norm_nm']>.1:
            raise RuntimeError('source contains trial outside proposed relaxed return screen')
        if i==0:train.append(load_sample(row,True))
        (held if row['holdout'] else train).append(load_sample(row))
    legacy=fit_gravity(train)
    g=np.array([s['rotation_base_tool'].T@np.array([0,0,-GRAVITY]) for s in train])
    measured=np.array([s['wrench'][:3] for s in train])
    initial=np.r_[legacy['mass_kg'],Rotation.from_matrix(legacy['rotation_sensor_from_tool']).as_rotvec(),legacy['force_bias_n']]
    def force_prediction(x):return x[0]*(g@Rotation.from_rotvec(x[1:4]).as_matrix().T)+x[4:7]
    solution=least_squares(lambda x:(force_prediction(x)-measured).reshape(-1),initial,
                           bounds=(np.r_[.05,[-np.inf]*6],np.r_[10.,[np.inf]*6]),max_nfev=5000,
                           ftol=1e-12,xtol=1e-12,gtol=1e-12)
    if not solution.success:raise RuntimeError('nonlinear force fit failed')
    x=solution.x;fg=force_prediction(x)-x[4:7]
    A=np.vstack([np.hstack([-skew(f),np.eye(3)]) for f in fg])
    torque=np.array([s['wrench'][3:] for s in train]);coef,_,rank,_=np.linalg.lstsq(A,torque.reshape(-1),rcond=None)
    if rank!=6:raise RuntimeError('torque model rank deficient')
    physical={'mass_kg':float(x[0]),'rotation_sensor_from_tool':Rotation.from_rotvec(x[1:4]).as_matrix().tolist(),
              'force_bias_n':x[4:7].tolist(),'com_sensor_m':coef[:3].tolist(),'torque_bias_nm':coef[3:].tolist(),
              'force_jacobian_condition':float(np.linalg.cond(solution.jac))}
    report={'status':'offline_diagnostic_only','active':False,'source':str(args.session),
            'installation_label':d['installation_label'],
            'proposed_return_screen_only':{'force_vector_n':.5,'torque_vector_nm':.1},
            'screen_not_changed_in_collection':True,
            'warning':'effective payload parameters may absorb cable loads; no independently weighed mass or physical CoM validation; local static scope only',
            'training_count':len(train),'heldout_count':len(held),'methods':{}}
    for name,model in [('existing_linear_projection',legacy),('constrained_force_then_physical_torque',physical)]:
        result={'model':model,'training':metrics(train,model),'heldout_angles':metrics(held,model),'later_repeat_validation':[]}
        for path in args.extra_validation:
            other=json.loads(path.read_text())
            if other['installation_label']!=d['installation_label']:raise RuntimeError('installation changed')
            samples=[load_sample(row) for row in other['pairs']]
            result['later_repeat_validation'].append({'session':str(path),'metrics':metrics(samples,model)})
        report['methods'][name]=result
    output=args.session.with_name('gravity-relaxed-offline-review.json')
    save(output,report)
    for name,r in report['methods'].items():
        print(name,'mass_kg',r['model']['mass_kg'],'com_mm',(np.asarray(r['model']['com_sensor_m'])*1000).tolist())
        for label in ['training','heldout_angles']:
            m=r[label];print(label,{k:v for k,v in m.items() if k!='residuals_n_nm'})
        for row in r['later_repeat_validation']:
            print('later_repeat',row['session'],{k:v for k,v in row['metrics'].items() if k!='residuals_n_nm'})
    print('OUTPUT',output)


if __name__=='__main__':main()
