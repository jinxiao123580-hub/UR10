import csv
import gzip
import sys
from contextlib import ExitStack
from pathlib import Path
import tempfile
sys.path.insert(0,'/home/jx/UR10/scripts')
from dataset_motion_storage import MotionStorage

def force(t):return [t,t,t,'sensor',1.,2.,3.,0.,0.,0.]
def ur(t,moving=False):return [t,t,t]+[0.]*12+[.001 if moving else 0.]+[0.]*5
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp);meta={'force_rows':0,'ur_rows':0};events=[]
    with ExitStack() as stack:
        s=MotionStorage(stack,root,meta,idle=1,pre=.5,marker=lambda *a:events.append(a))
        s.accept('ur',ur(0));s.accept('force',force(.1))
        s.accept('force',force(1.1));assert not s.active
        for i in range(300):s.accept('force',force(1.2+i*.01))
        assert meta['force_rows']==1 and len(s.buffers['force'])<=51
        s.accept('ur',ur(4.2,True));assert s.active
        assert 1<meta['force_rows']<55
        s.accept('force',force(4.21));s.finish()
    assert any(e[0]=='recording_pause' for e in events) and any(e[0]=='recording_resume' for e in events)
    rows=list(csv.reader(gzip.open(root/'force.csv.gz','rt')))
    assert len(rows)-1==meta['force_rows']
    assert not (root/'ur-frames.bin.gz').exists()
    stats=list(csv.reader(gzip.open(root/'idle-force-summary.csv.gz','rt')))
    assert len(stats)==2 and int(stats[1][2])==301
with tempfile.TemporaryDirectory() as tmp:
    meta={'force_rows':0,'ur_rows':0}
    with ExitStack() as stack:
        s=MotionStorage(stack,Path(tmp),meta,idle=1,continuous=True)
        s.accept('force',force(0));s.accept('force',force(100));s.finish()
        assert s.active and meta['force_rows']==2
print('PASS: pause, resume, bounded prebuffer, gzip readback, idle summary, continuous override')
