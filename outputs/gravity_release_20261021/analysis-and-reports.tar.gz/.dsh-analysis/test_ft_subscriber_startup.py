"""Extract the real sampler method; test without ROS, robot or Pinocchio."""
import ast
from collections import deque
from pathlib import Path
import threading
import numpy as np

tree=ast.parse(Path('/home/jx/.dsh-analysis/small_angle_ft_probe_20261012.py').read_text())
method=next(m for c in tree.body if isinstance(c,ast.ClassDef) and c.name=='RosRawWrench' for m in c.body if isinstance(m,ast.FunctionDef) and m.name=='sample')

class Clock:
    def __init__(self,sensor,deliver):self.now=0.;self.sensor=sensor;self.deliver=deliver;self.index=0
    def monotonic(self):return self.now
    def sleep(self,duration):
        end=self.now+duration
        while self.now+.005<=end+1e-9:
            self.now+=.005;self.index+=1
            if self.deliver and self.now>=.5:
                value=float(self.index)*.00001
                self.sensor.rows.append((self.now,1000+self.now,1000+self.now,(value,0,0,0,0,0)))
        self.now=end

class Sensor:
    def __init__(self):self.rows=deque(maxlen=4000);self.lock=threading.Lock()

for deliver in [True,False]:
    s=Sensor();clock=Clock(s,deliver);namespace={'time':clock,'np':np}
    exec(compile(ast.Module(body=[method],type_ignores=[]),'real_sampler','exec'),namespace)
    if deliver:
        result=namespace['sample'](s,1.)
        assert result['count']>=190 and result['first_time']>=1000.5
    else:
        try:namespace['sample'](s,1.)
        except RuntimeError as exc:assert 'within 5s' in str(exc)
        else:raise AssertionError('missing stream must prevent sampling')
print('PASS: delayed subscription waits then measures full window; absent data fails closed')
