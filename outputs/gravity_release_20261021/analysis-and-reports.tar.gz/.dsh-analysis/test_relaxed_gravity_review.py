"""Synthetic known mass/rotation/CoM recovery, no hardware."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import numpy as np
from scipy.spatial.transform import Rotation as R
from calibrate_pen_tcp import save

mass=3.2;com=np.array([-.08,.07,.06]);rs=R.from_euler('z',45,degrees=True).as_matrix()
bf=np.array([9.,4.,38.]);bt=np.array([-.2,.1,-.3]);home=R.from_euler('xyz',[175,4,20],degrees=True)
def wrench(rotation):
    f=mass*rs@rotation.as_matrix().T@np.array([0,0,-9.80665])
    return np.r_[f+bf,np.cross(com,f)+bt].tolist()
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp);rows=[]
    for i,(axis,angle) in enumerate([(a,b) for b in [15,-15,20,-20,12,-12] for a in ['x','y']]):
        v=np.zeros(3);v[0 if axis=='x' else 1]=np.deg2rad(angle);rotation=home*R.from_rotvec(v)
        path=root/('pose-%02d.json'%i)
        save(path,{'before_tcp_at_force_window_m_rad':[0,0,.5,*home.as_rotvec()],
                   'after_tcp_m_rad':[0,0,.5,*rotation.as_rotvec()],
                   'raw_before':{'mean':wrench(home)},'raw_after':{'mean':wrench(rotation)}})
        rows.append({'axis':axis,'angle_deg':angle,'holdout':abs(angle)==12,
                     'pose_return_passed':True,'return_force_norm_n':0.,'return_torque_norm_nm':0.,'out':str(path)})
    session=root/'session.json';save(session,{'pairs':rows,'installation_label':'synthetic'})
    subprocess.run([sys.executable,str(Path(__file__).with_name('fit_relaxed_gravity_review.py')),'--session',str(session)],check=True,capture_output=True)
    report=json.loads((root/'gravity-relaxed-offline-review.json').read_text())
    fitted=report['methods']['constrained_force_then_physical_torque']
    assert abs(fitted['model']['mass_kg']-mass)<1e-5
    assert np.linalg.norm(np.array(fitted['model']['com_sensor_m'])-com)<1e-6
    assert fitted['heldout_angles']['force_vector_max_n']<1e-6
    assert fitted['heldout_angles']['torque_vector_max_nm']<1e-6
print('PASS: known mass, sensor rotation, bias and CoM recovered; held-out forward wrench verified; no hardware')
