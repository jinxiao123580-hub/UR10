#!/usr/bin/env python3
"""Explicitly authorized local single-axis trial; no compensation writes."""
import datetime as dt
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
from scipy.spatial.transform import Rotation
from calibrate_pen_tcp import save

ROOT=Path('/home/jx/UR10')
sys.path.insert(0,str(ROOT/'scripts'))
from calibrate_ft_gravity import fit_gravity,GRAVITY

FOLDER=ROOT/'outputs/ft_calibration/local-new-cable-20261021'
SCRIPT=Path(__file__).with_name('small_angle_ft_probe_20261012.py')


def pose_difference(a,b):
    a,b=np.asarray(a),np.asarray(b)
    return float(np.linalg.norm(a[:3]-b[:3])*1000),float((Rotation.from_rotvec(a[3:]).inv()*Rotation.from_rotvec(b[3:])).magnitude()*180/np.pi)


def main():
    FOLDER.mkdir(parents=True,exist_ok=True)
    manifest=FOLDER/'session.json'
    if manifest.exists():
        raise RuntimeError('session exists; refusing automatic replay')
    initial=json.loads((FOLDER.parent/'new-cable-x10-out-20261021.json').read_text())
    home=initial['before_tcp_at_force_window_m_rad']
    session={'created_at':dt.datetime.now().astimezone().isoformat(),'status':'collecting',
             'gravity_compensation_enabled':False,'installation':'new cable routing; 2026-10-21',
             'home_tcp_m_rad':home,'pairs':[],'force_return_limit_n':.3,'torque_return_limit_nm':.05,
             'scope':'single-axis local +/-10 deg only; candidate not active'}
    save(manifest,session)
    targets=[('x',5),('x',-5),('x',-10),('y',5),('y',-5),('y',10),('y',-10),
             ('x',7.5),('x',-7.5),('y',7.5),('y',-7.5)]
    try:
        for axis,angle in targets:
            tag=axis+('%+.1f'%angle)
            paths=[]
            for name,amount in [('out',angle),('back',-angle)]:
                path=FOLDER/(tag+'-'+name+'.json')
                print('LOCAL CALIBRATION',tag,name,flush=True)
                subprocess.run([sys.executable,str(SCRIPT),'--axis',axis,'--angle-deg',str(amount),
                                '--execute','--output',str(path)],check=True)
                paths.append(path)
            out,back=[json.loads(p.read_text()) for p in paths]
            delta=np.asarray(back['raw_after']['mean'])-np.asarray(out['raw_before']['mean'])
            position,angle_error=pose_difference(home,back['after_tcp_m_rad'])
            row={'axis':axis,'angle_deg':angle,'holdout':abs(angle)==7.5,
                 'out':str(paths[0]),'back':str(paths[1]),'return_wrench_delta':delta.tolist(),
                 'return_force_norm_n':float(np.linalg.norm(delta[:3])),
                 'return_torque_norm_nm':float(np.linalg.norm(delta[3:])),
                 'return_position_mm':position,'return_rotation_deg':angle_error}
            session['pairs'].append(row); save(manifest,session)
            print('RETURN CHECK',json.dumps(row,ensure_ascii=False),flush=True)
            if position>.5 or angle_error>.1 or row['return_force_norm_n']>.3 or row['return_torque_norm_nm']>.05:
                raise RuntimeError('returned pose/baseline failed reproducibility gate; collection stopped')
        session['status']='collected_pending_fit'
        # The historical +10 X sample plus seven new training orientations.
        train=[{'rotation_base_tool':Rotation.from_rotvec(home[3:]).as_matrix(),
                'wrench':np.asarray(initial['raw_before']['mean'])},
               {'rotation_base_tool':Rotation.from_rotvec(initial['after_tcp_m_rad'][3:]).as_matrix(),
                'wrench':np.asarray(initial['raw_after']['mean'])}]
        held=[]
        for row in session['pairs']:
            d=json.loads(Path(row['out']).read_text())
            sample={'rotation_base_tool':Rotation.from_rotvec(d['after_tcp_m_rad'][3:]).as_matrix(),
                    'wrench':np.asarray(d['raw_after']['mean'])}
            (held if row['holdout'] else train).append(sample)
        try:
            model=fit_gravity(train)
            R=np.asarray(model['rotation_sensor_from_tool']); c=np.asarray(model['com_sensor_m'])
            residuals=[]
            for s in held:
                fg=model['mass_kg']*R@s['rotation_base_tool'].T@np.array([0,0,-GRAVITY])
                predicted=np.r_[fg+model['force_bias_n'],np.cross(c,fg)+model['torque_bias_nm']]
                residuals.append((s['wrench']-predicted).tolist())
            e=np.asarray(residuals)
            session['candidate_model']=model
            session['holdout_residuals']=residuals
            session['holdout_force_rms_n']=float(np.sqrt(np.mean(e[:,:3]**2)))
            session['holdout_torque_rms_nm']=float(np.sqrt(np.mean(e[:,3:]**2)))
            session['status']='local_candidate_requires_review'
        except ValueError as exc:
            session['status']='collected_model_rejected'; session['fit_error']=str(exc)
    except BaseException as exc:
        session['status']='stopped_on_error'; session['error']=str(exc)
        raise
    finally:
        save(manifest,session)
        print('SESSION',manifest,'STATUS',session['status'],flush=True)


if __name__=='__main__':
    main()
