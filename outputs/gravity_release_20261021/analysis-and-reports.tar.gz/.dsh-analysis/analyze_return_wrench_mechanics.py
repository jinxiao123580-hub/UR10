"""Exploratory load-path diagnostic, NOT gravity compensation identification."""
import argparse
import json
from pathlib import Path
import numpy as np
from calibrate_pen_tcp import save


def skew(v):
    x,y,z=v
    return np.array([[0,-z,y],[z,0,-x],[-y,x,0]])


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--session',type=Path,required=True)
    a=p.parse_args();d=json.loads(a.session.read_text())
    train=[r for r in d['pairs'] if not r['holdout']]
    held=[r for r in d['pairs'] if r['holdout']]
    force=np.array([r['return_wrench_delta'][:3] for r in train])
    torque=np.array([r['return_wrench_delta'][3:] for r in train])
    design=np.vstack([-skew(f) for f in force])
    lever,_,rank,s=np.linalg.lstsq(design,torque.reshape(-1),rcond=None)
    train_error=torque-np.array([np.cross(lever,f) for f in force])
    hf=np.array([r['return_wrench_delta'][:3] for r in held])
    ht=np.array([r['return_wrench_delta'][3:] for r in held])
    he=ht-np.array([np.cross(lever,f) for f in hf])
    report={'kind':'exploratory_return_wrench_load_path','source':str(a.session),
            'is_gravity_calibration':False,'active':False,
            'uses_rejected_trials_for_disturbance_analysis_only':True,
            'equation':'delta_tau = effective_r cross delta_F; no fitted intercept',
            'coordinates':'same sensor axes as recorded wrench; not robot-base coordinates',
            'effective_lever_m':lever.tolist(),'rank':int(rank),'condition':float(s[0]/s[-1]),
            'train_count':len(train),'heldout_count':len(held),
            'train_torque_component_rms_nm':float(np.sqrt(np.mean(train_error**2))),
            'heldout_torque_component_rms_nm':float(np.sqrt(np.mean(he**2))),
            'heldout_raw_torque_component_rms_nm':float(np.sqrt(np.mean(ht**2))),
            'heldout_max_residual_vector_nm':float(np.linalg.norm(he,axis=1).max()),
            'heldout_residuals_nm':he.tolist(),
            'limitation':'An effective lever is not a uniquely identified physical cable anchor. Sensor cross-coupling, other loads and drift were not independently eliminated.'}
    output=a.session.with_name('return-load-path-diagnostic.json')
    save(output,report);print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
