#!/usr/bin/env python3
"""One guarded, at-most-10-degree ATI response probe; NOT gravity calibration.

No payload, hardware Bias, Tare, or compensation configuration is changed.
The execute mode makes exactly one rotation-only move and never auto-returns.
"""
import argparse
from collections import deque
import datetime as dt
import json
import math
import os
from pathlib import Path
import socket
import sys
import threading
import time

import numpy as np
import pinocchio as pin

ROOT = Path('/home/jx/UR10')
sys.path.insert(0, str(ROOT / 'scripts'))
from calibrate_ft_gravity import matrix_to_rotvec_near, rotvec_to_matrix  # noqa: E402
from check_move_plan import BASE_FROM_URDF_ROOT, check_segment, pose_from_tcp_target, robot_pose  # noqa: E402
from read_ur_state import dashboard  # noqa: E402
from record_ur_trajectory import RealtimeReader  # noqa: E402
from self_collision import SelfCollisionModel  # noqa: E402
from ur_pose_ik import UR10IK  # noqa: E402

HOST = '192.168.1.3'
OUT = ROOT / 'outputs/ft_calibration/small-angle-probe-20261012.json'


def stopj():
    try:
        with socket.create_connection((HOST, 30002), timeout=2) as sock:
            sock.sendall(b'stopj(2.0)\n')
    except OSError as exc:
        print('WARNING: stopj could not be sent:', exc, file=sys.stderr, flush=True)


def ur_status():
    mode = dashboard('robotmode')
    safety = dashboard('safetystatus')
    program = dashboard('programState')
    if mode != 'Robotmode: RUNNING' or safety != 'Safetystatus: NORMAL' or not (program or '').startswith('STOPPED'):
        raise RuntimeError(f'controller not RUNNING/NORMAL/STOPPED: {mode} / {safety} / {program}')
    return {'robotmode': mode, 'safetystatus': safety, 'programState': program}


class RosRawWrench:
    """Read-only subscriber; the dashboard ATI node remains the sole RDT owner."""

    def __init__(self):
        import rclpy
        from geometry_msgs.msg import WrenchStamped
        from rclpy.node import Node
        rclpy.init(args=None)
        self.rclpy = rclpy
        self.rows = deque(maxlen=4000)
        self.lock = threading.Lock()
        self.node = Node('small_angle_ft_probe_%d' % os.getpid())

        def callback(msg):
            w = msg.wrench
            values = (w.force.x, w.force.y, w.force.z,
                      w.torque.x, w.torque.y, w.torque.z)
            source = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
            received = time.time()
            with self.lock:
                self.rows.append((time.monotonic(), received, source, values))

        self.subscription = self.node.create_subscription(
            WrenchStamped, '/ft_sensor/wrench_raw', callback, 200)
        self.thread = threading.Thread(target=rclpy.spin, args=(self.node,), daemon=True)
        self.thread.start()

    def sample(self, duration=1.0):
        # DDS discovery is asynchronous. Start the measurement window only
        # after this subscriber actually receives recent source-stamped data.
        ready_deadline=time.monotonic()+5
        while time.monotonic()<ready_deadline:
            with self.lock:
                latest=list(self.rows)[-20:]
            if (len(latest)>=20 and time.monotonic()-latest[-1][0]<.15
                    and -.1<=latest[-1][1]-latest[-1][2]<=.3):
                break
            time.sleep(.05)
        else:
            raise RuntimeError('no fresh ROS raw-wrench stream within 5s; no valid sample')
        begin = time.monotonic()
        time.sleep(duration)
        end = time.monotonic()
        with self.lock:
            rows = [r for r in self.rows if begin <= r[0] <= end]
        if len(rows) < max(50, int(duration * 50)):
            raise RuntimeError('ROS raw-wrench rate too low: %d in %.1fs' % (len(rows), duration))
        ages = np.asarray([r[1] - r[2] for r in rows], dtype=float)
        if not np.all(np.isfinite(ages)) or np.min(ages) < -0.1 or np.max(ages) > 0.3:
            raise RuntimeError('ROS raw-wrench message timestamp is stale or invalid')
        array = np.asarray([r[3] for r in rows], dtype=float)
        if not np.all(np.isfinite(array)) or len(np.unique(array, axis=0)) < 20:
            raise RuntimeError('ROS raw-wrench values are nonfinite or appear frozen')
        return {'count': len(rows), 'mean': array.mean(axis=0).tolist(),
                'std': array.std(axis=0).tolist(),
                'first_time': rows[0][1], 'last_time': rows[-1][1],
                'max_message_age_ms': float(np.max(ages) * 1000),
                'unique_value_count': int(len(np.unique(array, axis=0))),
                'topic': '/ft_sensor/wrench_raw'}

    def close(self):
        self.node.destroy_node()
        self.rclpy.shutdown()
        self.thread.join(timeout=2.0)


def sample_ft(sensor, duration=1.0):
    return sensor.sample(duration)


def write_report(report, output):
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    os.replace(temporary, output)


def orientation_error(actual, target):
    first = rotvec_to_matrix(actual[3:])
    second = rotvec_to_matrix(target[3:])
    return float(np.linalg.norm(pin.log3(first.T @ second)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--axis', choices=['x', 'y'], default='x')
    parser.add_argument('--angle-deg', type=float, default=5.0)
    parser.add_argument('--max-angle-deg',type=float,choices=[10.,20.],default=10.,
                        help='explicitly approved single-axis envelope; default remains 10 degrees')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output', default=str(OUT))
    parser.add_argument('--return-to-json', type=Path,
                        help='return to the exact measured start of a successful prior probe')
    args = parser.parse_args()
    if not 0 < abs(args.angle_deg) <= args.max_angle_deg:
        parser.error('probe exceeds explicitly selected angular envelope')
    output = Path(args.output).resolve()
    if output == (ROOT / 'config/ft_gravity_calibration.yaml'):
        parser.error('refusing to overwrite active gravity configuration')
    report = {'kind': 'one_step_ft_response_probe', 'created_at': dt.datetime.now().astimezone().isoformat(),
              'gravity_model_valid': False, 'motion_sent': False, 'axis': args.axis,
              'angle_deg': args.angle_deg, 'status': 'preflight'}
    reader = RealtimeReader(HOST, port=30013)
    sensor = None
    try:
        q, before, velocity = reader.read(max_wait_seconds=5)
        report['before_tcp_m_rad'] = list(before)
        report['before_q_rad'] = list(q)
        if float(np.linalg.norm(velocity[:3])) > 0.003 or float(np.linalg.norm(velocity[3:])) > 0.02:
            raise RuntimeError('robot is moving before probe')
        report['controller'] = ur_status()
        ik = UR10IK()
        fk_error = pin.log6((BASE_FROM_URDF_ROOT * ik.pose(q)).inverse() * robot_pose(before)).vector
        if np.linalg.norm(fk_error[:3]) > 0.010 or np.linalg.norm(fk_error[3:]) > 0.020:
            raise RuntimeError('controller TCP disagrees with model FK')
        direction = np.zeros(3)
        direction[0 if args.axis == 'x' else 1] = math.radians(args.angle_deg)
        target_r = rotvec_to_matrix(before[3:]) @ pin.exp3(direction)
        target = list(before[:3]) + matrix_to_rotvec_near(target_r, before[3:]).tolist()
        if args.return_to_json:
            source=json.loads(args.return_to_json.read_text())
            if source.get('status')!='measured_not_calibrated':
                raise RuntimeError('return source is not a successful probe')
            target=np.asarray(source['before_tcp_at_force_window_m_rad'],dtype=float).tolist()
            if len(target)!=6 or not np.isfinite(target).all():
                raise RuntimeError('invalid absolute return target')
            if math.dist(before[:3],target[:3])>.001 or orientation_error(before,target)>math.radians(args.max_angle_deg+.05):
                raise RuntimeError('absolute return outside the local trial envelope')
            report['absolute_return_source']=str(args.return_to_json)
        report['target_tcp_m_rad'] = target
        gate = check_segment(ik, robot_pose(before), pose_from_tcp_target(target), q, 80,
                             SelfCollisionModel(), 0.020)
        report['path_gate'] = gate
        worst = gate['worst']
        if (gate['reasons'] or worst['joint_margin_rad'] < math.radians(5)
                or worst['min_singular'] < 0.02):
            raise RuntimeError('model path gate rejected: ' + str(gate['reasons'][:3] or worst))
        sensor = RosRawWrench()
        pre = sample_ft(sensor)
        report['raw_before'] = pre
        # Repositioning a cable can leave a short transient. Retry complete
        # stationary windows at rest; never loosen the original noise gates.
        for baseline_attempt in range(2):
            if np.max(pre['std'][:3])<=0.5 and np.max(pre['std'][3:])<=0.05:
                break
            report.setdefault('baseline_unstable_attempts',[]).append(pre)
            time.sleep(1)
            pre=sample_ft(sensor)
            report['raw_before']=pre
        if np.max(pre['std'][:3]) > 0.5 or np.max(pre['std'][3:]) > 0.05:
            raise RuntimeError('ATI baseline is not static enough')
        if not args.execute:
            report['status'] = 'dry_run_pass'
            write_report(report, output)
            print('DRY-RUN PASS; no motion sent. target=', [round(x, 6) for x in target], flush=True)
            print('ATI baseline N/Nm=', [round(x, 4) for x in pre['mean']], flush=True)
            print('REPORT:', output)
            return
        # Recheck immediately before the single command. The tool is not used
        # for an automatic return: any failure leaves the arm where it stopped.
        report['controller_immediately_before'] = ur_status()
        # Drop any queued 30013 frames accumulated while fitting/checking the
        # path and sampling ATI. The first frame on a new socket is current.
        reader.connect()
        q_now, tcp_now, velocity_now = reader.read(max_wait_seconds=5)
        if (np.max(np.abs(np.asarray(q_now) - np.asarray(q))) > 0.01
                or math.dist(tcp_now[:3], before[:3]) > 0.0005
                or orientation_error(tcp_now, before) > math.radians(0.1)
                or np.linalg.norm(velocity_now[:3]) > 0.003):
            raise RuntimeError('robot moved after gate; no command sent')
        report['before_tcp_at_force_window_m_rad'] = list(tcp_now)
        report['status'] = 'commanding'
        write_report(report, output)
        program = ("def ft_small_probe():\n  movel(p[%s], a=0.010000, v=0.005000)\n"
                   "end\n") % ', '.join('%.9f' % value for value in target)
        # The controller may accept part of a command even if sendall raises.
        report['motion_sent'] = True
        with socket.create_connection((HOST, 30002), timeout=3) as sock:
            sock.sendall(program.encode('ascii'))
        write_report(report, output)
        deadline = time.monotonic() + 35.0
        settled = False
        latest = tcp_now
        while time.monotonic() < deadline:
            _q, latest, speed = reader.read(max_wait_seconds=2)
            if (math.dist(latest[:3], target[:3]) < 0.0002
                    and orientation_error(latest, target) < math.radians(0.05)
                    and np.linalg.norm(speed[:3]) < 0.0005
                    and np.linalg.norm(speed[3:]) < 0.005):
                settled = True
                break
        if not settled:
            raise RuntimeError('probe did not settle to 0.2 mm / 0.05 deg before watchdog')
        # Leave the dashboard-owned RDT stream untouched. Discard one ROS window
        # after settling, then take a fresh stationary window.
        time.sleep(1.5)
        sample_ft(sensor)
        post = None
        for attempt in range(3):
            candidate = sample_ft(sensor)
            if np.max(candidate['std'][:3]) <= 0.5 and np.max(candidate['std'][3:]) <= 0.05:
                post = candidate
                break
            report.setdefault('post_unstable_attempts', []).append(candidate)
            time.sleep(1.0)
        if post is None:
            raise RuntimeError('ATI after-motion wrench did not become static; do not use this sample')
        # A second fresh state must agree with the pose that produced the
        # force window; otherwise drift or buffered UR frames invalidate it.
        reader.connect()
        _q_after, tcp_after, speed_after = reader.read(max_wait_seconds=5)
        if (math.dist(tcp_after[:3], target[:3]) > 0.0003
                or orientation_error(tcp_after, target) > math.radians(0.08)
                or np.linalg.norm(speed_after[:3]) > 0.0005
                or np.linalg.norm(speed_after[3:]) > 0.005):
            raise RuntimeError('post-force UR pose is not stationary at target')
        report['after_tcp_m_rad'] = list(tcp_after)
        report['ur_reconnect_count'] = reader.reconnects
        report['raw_after'] = post
        report['delta_wrench'] = (np.asarray(post['mean']) - np.asarray(pre['mean'])).tolist()
        report['status'] = 'measured_not_calibrated'
        write_report(report, output)
        print('PROBE COMPLETE; no gravity model produced', flush=True)
        print('ATI delta N/Nm=', [round(x, 4) for x in report['delta_wrench']], flush=True)
        print('REPORT:', output)
    except BaseException as exc:
        if report['motion_sent']:
            stopj()
        report['status'] = 'failed'
        report['error'] = str(exc)
        write_report(report, output)
        raise
    finally:
        if sensor is not None:
            sensor.close()
        reader.close()


if __name__ == '__main__':
    main()
