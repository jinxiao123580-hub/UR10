#!/usr/bin/env python3
"""Read-only stationary ATI drift baseline; never commands the robot or sensor."""
import argparse
import datetime as dt
import json
import math
import os
from pathlib import Path
import sys

import numpy as np

ROOT = Path('/home/jx/UR10')
sys.path.insert(0, str(ROOT / 'scripts'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from record_ur_trajectory import RealtimeReader  # noqa: E402
from small_angle_ft_probe_20261012 import RosRawWrench, orientation_error  # noqa: E402


def fresh_state():
    reader = RealtimeReader('192.168.1.3', port=30013)
    try:
        q, tcp, speed = reader.read(max_wait_seconds=5)
        return {'q_rad': list(q), 'tcp_m_rad': list(tcp),
                'speed': list(speed)}
    finally:
        reader.close()


def atomic_json(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
    os.replace(temporary, path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--windows', type=int, default=12)
    parser.add_argument('--duration', type=float, default=5.0)
    parser.add_argument('--output', default=str(ROOT / 'outputs/ft_calibration/static-drift-20261012.json'))
    args = parser.parse_args()
    if not 2 <= args.windows <= 360 or not 1 <= args.duration <= 30:
        parser.error('windows must be 2..360 and duration 1..30 s')
    output = Path(args.output).resolve()
    report = {'kind': 'stationary_ft_drift_baseline', 'created_at': dt.datetime.now().astimezone().isoformat(),
              'motion_sent': False, 'gravity_compensation_enabled': False,
              'topic': '/ft_sensor/wrench_raw', 'joint_limit_minimum_deg_for_future_paths': 3.0,
              'joint_limit_planning_margin_deg': 5.0, 'windows': [], 'status': 'collecting'}
    sensor = RosRawWrench()
    try:
        for index in range(args.windows):
            before = fresh_state()
            sample = sensor.sample(args.duration)
            after = fresh_state()
            translation_mm = math.dist(before['tcp_m_rad'][:3], after['tcp_m_rad'][:3]) * 1000
            rotation_deg = math.degrees(orientation_error(before['tcp_m_rad'], after['tcp_m_rad']))
            speed = np.asarray(after['speed'], dtype=float)
            accepted = (translation_mm <= 0.2 and rotation_deg <= 0.05
                        and np.linalg.norm(speed[:3]) <= 0.0005
                        and np.linalg.norm(speed[3:]) <= 0.005)
            report['windows'].append({'index': index + 1, 'accepted_stationary': bool(accepted),
                                      'tcp_motion_mm': translation_mm, 'tcp_rotation_deg': rotation_deg,
                                      'state_before': before, 'state_after': after, 'raw_wrench': sample})
            atomic_json(output, report)
            print('window %d/%d: %s, F=%s N, TCP motion %.3f mm / %.4f deg' %
                  (index + 1, args.windows, 'static' if accepted else 'REJECTED',
                   [round(value, 4) for value in sample['mean'][:3]], translation_mm, rotation_deg),
                  flush=True)
        valid = [row for row in report['windows'] if row['accepted_stationary']]
        if len(valid) < args.windows:
            report['status'] = 'incomplete_or_moving'
        else:
            force = np.asarray([row['raw_wrench']['mean'][:3] for row in valid])
            torque = np.asarray([row['raw_wrench']['mean'][3:] for row in valid])
            report['force_range_n'] = np.ptp(force, axis=0).tolist()
            report['torque_range_nm'] = np.ptp(torque, axis=0).tolist()
            report['status'] = 'static_baseline_recorded'
        atomic_json(output, report)
        print('OUTPUT:', output, 'STATUS:', report['status'], flush=True)
        return 0 if report['status'] == 'static_baseline_recorded' else 1
    except Exception as exc:
        report['status'] = 'failed'
        report['error'] = str(exc)
        atomic_json(output, report)
        raise
    finally:
        sensor.close()


if __name__ == '__main__':
    raise SystemExit(main())
