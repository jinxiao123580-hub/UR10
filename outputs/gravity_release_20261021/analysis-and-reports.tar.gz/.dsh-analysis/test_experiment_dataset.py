"""No hardware: realtime framing across arbitrary TCP packet boundaries."""
import importlib.util
from pathlib import Path
import struct
import threading
import sys
sys.path.insert(0,'/home/jx/UR10/scripts')
spec=importlib.util.spec_from_file_location('rec',Path('/home/jx/UR10/scripts/record_experiment_dataset.py'))
rec=importlib.util.module_from_spec(spec);spec.loader.exec_module(rec)

class Sock:
    def __init__(self,chunks):self.chunks=iter(chunks)
    def recv(self,size):return next(self.chunks,b'')

frame=bytearray(1220);struct.pack_into('>I',frame,0,1220);struct.pack_into('>d',frame,4,123.)
data=bytes(frame);stop=threading.Event()
stream=rec.frames(Sock([data[:2],data[2:300],data[300:]+data]),stop)
assert next(stream)==data and next(stream)==data
try:next(stream)
except ConnectionError:pass
else:raise AssertionError('closed connection must be reported')
try:next(rec.frames(Sock([b'\x00\x00\x00\x08']),stop))
except ValueError:pass
else:raise AssertionError('invalid framing must fail')
print('PASS: split headers/bodies, multiple frames per packet, closure and invalid-frame detection')
