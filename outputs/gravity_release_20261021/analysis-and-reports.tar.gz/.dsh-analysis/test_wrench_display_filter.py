import sys
import unittest
import math
sys.path.insert(0, '/home/jx/UR10/scripts')
from filter_wrench_display import LowPass

class FilterTest(unittest.TestCase):
    def test_constant_step_and_gap(self):
        f = LowPass(5)
        self.assertEqual(f.update([0]*6, 1), [0]*6)
        for i in range(1,201):
            value = f.update([1]*6, 1+i*.005)
        self.assertAlmostEqual(value[0], 1, places=10)
        self.assertEqual(f.update([9]*6, 3), [9]*6)
        self.assertIsNone(f.update([0]*6, 3))
        self.assertIsNone(f.update([float('nan')]*6, 4))

    def test_attenuation(self):
        f = LowPass(5)
        values = [f.update([math.sin(2*math.pi*40*i/200)]*6, i/200)[0] for i in range(1000)]
        rms = math.sqrt(sum(x*x for x in values[200:])/800)
        self.assertLess(rms, .15)

if __name__ == '__main__': unittest.main()
