#!/usr/bin/env python3
"""Repeat approved single-axis +/-10 deg trials; never install a model."""
import argparse
import datetime as dt
import json
from pathlib import Path
import signal
import subprocess
import sys
import time
import numpy as np
from calibrate_pen_tcp import save
from collect_local_gravity_20261021 import pose_difference
from ft_static_drift_20261012 import fresh_state
from small_angle_ft_probe_20261012 import stopj,ur_status

ROOT=Path('/home/jx/UR10/outputs/ft_calibration')
SCRIPT=Path(__file__).with_name('small_angle_ft_probe_20261012.py')


def child(command):
    process=subprocess.Popen(command)
    try:
        if process.wait()!=0:
            raise RuntimeError('single motion/sample failed; no automatic return')
    except BaseException:
        if process.poll() is None:
            process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                stopj(); process.terminate()
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--site-confirmed',action='store_true')
    parser.add_argument('--repeats',type=int,default=3)
    parser.add_argument('--wide-gravity',action='store_true',help='explicitly approved +/-20 deg training and +/-12 deg holdouts')
    parser.add_argument('--other20',action='store_true',help='directional diagnostic: Y+20, Y-20, X-20')
    parser.add_argument('--negative20',action='store_true',help='remaining directional diagnostic: Y-20, X-20')
    parser.add_argument('--reverse-negative20',action='store_true',help='order control: X-20 then Y-20')
    parser.add_argument('--order-abba',action='store_true',help='counterbalanced blocks XY, YX, YX, XY at -20 deg')
    parser.add_argument('--x-refill',action='store_true',help='route-v2 X-only refill: -15,+15,-20,+20, then independent -12,+12')
    parser.add_argument('--continue-baseline-failure',action='store_true',help='ABBA diagnostic only: keep rejected wrench samples, continue only if pose/controller/data checks pass')
    parser.add_argument('--start-trial',type=int,default=1,help='ABBA continuation: first remaining trial 1..8')
    parser.add_argument('--return-reference',type=Path,help='ABBA continuation: preserve the first session absolute home')
    parser.add_argument('--fit-candidate',action='store_true',help='wide-gravity only: offline held-out review, no activation')
    parser.add_argument('--previous-session',type=Path,help='resume independent diagnostic trials after a returned-wrench rejection')
    parser.add_argument('--installation-label',default='cable-route-v1-20261021',help='physical installation identity; never mix fits across changes')
    args=parser.parse_args()
    if not args.execute or not args.site_confirmed or not 1<=args.repeats<=3:
        parser.error('requires --execute --site-confirmed; repeats 1..3')
    if sum([args.wide_gravity,args.other20,args.negative20,args.reverse_negative20,args.order_abba,args.x_refill])>1:
        parser.error('choose only one trial mode')
    if args.continue_baseline_failure and not (args.order_abba or args.wide_gravity or args.x_refill):
        parser.error('baseline-failure continuation requires an explicit diagnostic mode')
    if args.fit_candidate and not args.wide_gravity:parser.error('candidate fit requires wide-gravity')
    if not 1<=args.start_trial<=(12 if args.wide_gravity else 8) or ((args.start_trial!=1 or args.return_reference or args.previous_session) and not (args.order_abba or args.wide_gravity)):
        parser.error('continuation requires explicit ABBA or wide-gravity mode')
    if args.previous_session:
        previous=json.loads(args.previous_session.read_text())
        last=previous['pairs'][-1]
        if not last.get('pose_return_passed') or last.get('wrench_return_passed'):
            parser.error('previous session did not end solely on returned wrench rejection')
    folder=ROOT/('repeat-other-directions-'+dt.datetime.now().strftime('%Y%m%d-%H%M%S'))
    folder.mkdir(exist_ok=False)
    report={'status':'preflight','pairs':[],'motion_compensation_enabled':False,
            'angle_limit_deg':10,'repeats':args.repeats,
            'return_limits':{'force_norm_n':.3,'torque_norm_nm':.05,'position_mm':.5,'rotation_deg':.1}}
    report['installation_label']=args.installation_label
    maximum=20 if args.wide_gravity or args.other20 or args.negative20 or args.reverse_negative20 or args.order_abba or args.x_refill else 10
    report['angle_limit_deg']=maximum
    report['mode']='wide_gravity_train_holdout' if args.wide_gravity else 'local_repeatability'
    targets=([(axis,angle) for angle in [15,-15,20,-20] for axis in ['x','y']]+
             [(axis,angle) for angle in [12,-12] for axis in ['x','y']]) if args.wide_gravity else [('x',-10),('y',10),('y',-10)]
    if args.other20:
        report['mode']='other20_direction_diagnostic'
        targets=[('y',20),('y',-20),('x',-20)]
    if args.negative20:
        report['mode']='negative20_direction_diagnostic'
        targets=[('y',-20),('x',-20)]
    if args.reverse_negative20:
        report['mode']='reverse_negative20_order_control'
        targets=[('x',-20),('y',-20)]
    if args.order_abba:
        report['mode']='counterbalanced_AB_BA_BA_AB'
        targets=[(axis,-20) for axis in ['x','y','y','x','y','x','x','y']]
        report['post_return_dwell_seconds']=10
        report['continue_rejected_wrench_only']=args.continue_baseline_failure
    if args.wide_gravity:report['post_return_dwell_seconds']=10
    if args.x_refill:
        report['mode']='X_only_refill_train_holdout'
        report['post_return_dwell_seconds']=10
        targets=[('x',angle) for angle in [-15,15,-20,20,-12,12]]
    # Anchor this session once; each return uses the measured pre-out pose,
    # rather than adding an inverse rotation to an imperfect arrival pose.
    ur_status()
    home=fresh_state()['tcp_m_rad']
    if args.return_reference:
        source=json.loads(args.return_reference.read_text())
        if source.get('status')!='measured_not_calibrated':
            raise RuntimeError('invalid continuation reference')
        home=source['before_tcp_at_force_window_m_rad']
    report['home_tcp_m_rad']=home
    if args.previous_session:
        report['pairs']=previous['pairs']
        report['previous_session']=str(args.previous_session)
        report['continue_rejected_wrench_only']=args.continue_baseline_failure
    output=folder/'session.json'
    return_source=args.return_reference
    try:
        for repeat in range(1,args.repeats+1):
            for trial_index,(axis,angle) in enumerate(targets):
                if trial_index+1<args.start_trial:continue
                report['controller']=ur_status()
                state=fresh_state()
                distance,rotation=pose_difference(home,state['tcp_m_rad'])
                if distance>.5 or rotation>.1 or np.linalg.norm(state['speed'])>.001:
                    raise RuntimeError('start no longer stationary at approved home pose; no motion sent')
                tag='r%d-%s%+d'%(repeat,axis,angle)
                if args.order_abba:tag='t%02d-'%(trial_index+1)+tag
                row={'repeat':repeat,'axis':axis,'angle_deg':angle,'status':'sampling'}
                row['holdout']=(args.wide_gravity or args.x_refill) and abs(angle)==12
                if args.order_abba:
                    row.update({'block':trial_index//2+1,'block_order':['XY','YX','YX','XY'][trial_index//2],
                                'slot':trial_index%2+1})
                report['pending']=tag; report['status']='collecting'; save(output,report)
                paths=[]
                for phase,value in [('out',angle),('back',-angle)]:
                    path=folder/(tag+'-'+phase+'.json')
                    print('TRIAL',tag,phase,flush=True)
                    command=[sys.executable,str(SCRIPT),'--axis',axis,'--angle-deg',str(value),
                             '--max-angle-deg',str(maximum),'--execute','--output',str(path)]
                    if phase=='back':
                        command.extend(['--return-to-json',str(return_source)])
                    child(command)
                    paths.append(path)
                    if phase=='out' and return_source is None:
                        return_source=path
                        report['absolute_return_reference']=str(path)
                a,b=[json.loads(p.read_text()) for p in paths]
                delta=np.array(b['raw_after']['mean'])-a['raw_before']['mean']
                position,rotation=pose_difference(a['before_tcp_at_force_window_m_rad'],b['after_tcp_m_rad'])
                global_position,global_rotation=pose_difference(home,b['after_tcp_m_rad'])
                row.update({'out':str(paths[0]),'back':str(paths[1]),'return_wrench_delta':delta.tolist(),
                            'return_force_norm_n':float(np.linalg.norm(delta[:3])),
                            'return_torque_norm_nm':float(np.linalg.norm(delta[3:])),
                            'return_position_mm':position,'return_rotation_deg':rotation})
                row.update({'global_return_position_mm':global_position,
                            'global_return_rotation_deg':global_rotation})
                pose_ok=max(position,global_position)<=.5 and max(rotation,global_rotation)<=.1
                wrench_ok=row['return_force_norm_n']<=.3 and row['return_torque_norm_nm']<=.05
                passed=pose_ok and wrench_ok
                row.update({'pose_return_passed':pose_ok,'wrench_return_passed':wrench_ok})
                row['status']='passed' if passed else 'return_gate_failed'
                report['pairs'].append(row); save(output,report)
                print('RESULT',json.dumps(row,ensure_ascii=False),flush=True)
                if not pose_ok or (not wrench_ok and not args.continue_baseline_failure):
                    raise RuntimeError('return reproducibility failed; all remaining trials cancelled')
                if args.order_abba or args.wide_gravity or args.x_refill:
                    row['dwell_start_unix_s']=time.time();save(output,report)
                    time.sleep(10)
                    row['dwell_end_unix_s']=time.time();save(output,report)
        report['status']='completed_collection_not_calibrated'
    except BaseException as exc:
        report['status']='stopped_on_error';report['error']=str(exc)
        raise
    finally:
        save(output,report)
        print('REPORT',output,'STATUS',report['status'],flush=True)
    if args.fit_candidate:
        subprocess.run([sys.executable,str(Path(__file__).with_name('fit_local_gravity_candidate.py')),
                        '--session',str(output)],check=True)


if __name__=='__main__':
    main()
