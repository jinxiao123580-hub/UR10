"""Offline fit with explicit training/held-out split; never install a model."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
from scipy.spatial.transform import Rotation
from calibrate_pen_tcp import save
sys.path.insert(0,'/home/jx/UR10/scripts')
from calibrate_ft_gravity import fit_gravity,GRAVITY


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--session',type=Path,required=True)
    args=p.parse_args();session=json.loads(args.session.read_text())
    output=args.session.with_name('gravity-candidate-review.json')
    if output.exists():raise RuntimeError('candidate review exists; refusing overwrite')
    report={'source_session':str(args.session),'active':False,'status':'rejected',
            'scope':'static, same home position/cable routing; single-axis local range only',
            'excluded_trials':[],'training':[],'holdout':[]}
    train=[];held=[]
    for row in session['pairs']:
        if row['status']!='passed':report['excluded_trials'].append(row);continue
        d=json.loads(Path(row['out']).read_text())
        if not train and not row['holdout']:
            train.append({'rotation_base_tool':Rotation.from_rotvec(d['before_tcp_at_force_window_m_rad'][3:]).as_matrix(),
                          'wrench':np.asarray(d['raw_before']['mean'])})
        sample={'rotation_base_tool':Rotation.from_rotvec(d['after_tcp_m_rad'][3:]).as_matrix(),
                'wrench':np.asarray(d['raw_after']['mean'])}
        (held if row['holdout'] else train).append(sample)
        report['holdout' if row['holdout'] else 'training'].append(row['out'])
    report.update({'training_count':len(train),'holdout_count':len(held)})
    try:
        if len(held)!=4:raise ValueError('all four planned independent held-out poses must pass collection gates')
        model=fit_gravity(train);report['candidate']=model
        residual=[];rs=np.asarray(model['rotation_sensor_from_tool']);com=np.asarray(model['com_sensor_m'])
        for s in held:
            f=model['mass_kg']*rs@s['rotation_base_tool'].T@np.array([0,0,-GRAVITY])
            pred=np.r_[f+model['force_bias_n'],np.cross(com,f)+model['torque_bias_nm']]
            residual.append((s['wrench']-pred).tolist())
        e=np.asarray(residual)
        report['heldout_residuals_n_nm']=residual
        report['heldout_force_component_rms_n']=float(np.sqrt(np.mean(e[:,:3]**2)))
        report['heldout_torque_component_rms_nm']=float(np.sqrt(np.mean(e[:,3:]**2)))
        report['heldout_force_vector_max_n']=float(np.linalg.norm(e[:,:3],axis=1).max())
        report['heldout_torque_vector_max_nm']=float(np.linalg.norm(e[:,3:],axis=1).max())
        report['status']='candidate_requires_review_not_enabled'
    except ValueError as exc:report['reason']=str(exc)
    save(output,report)
    print('CANDIDATE REVIEW',output,report['status'],flush=True)


if __name__=='__main__':main()
