# Relaxed offline gravity-fit review

User requested the numerical result under reduced precision requirements.
No online/collection threshold was changed; no model enabled or uploaded.

Output with full models/residuals:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-101644/gravity-relaxed-offline-review.json`

Only cable-route-v2 data used. Proposed *offline return-screen* limits 0.5 N
force-vector change and 0.1 Nm torque-vector change include all original
12 collected poses. These limits are NOT guaranteed compensation errors.
Training = home + eight +/-15/+/-20 single-axis poses (9). Four +/-12 poses
kept out of parameter fitting. Two subsequent X-refill sessions (6 each)
also evaluated without parameter refit:
`repeat-other-directions-20261021-103020/session.json` and
`repeat-other-directions-20261021-103844/session.json` under ft_calibration.

## Methods and results

Existing linear-matrix-fit followed by mass/rotation projection:
mass 3.165919 kg; held-out force-component RMS .615839 N and max force-vector
residual 1.151472 N. Forward physical torque held-out component RMS .078210
Nm. This differs from the existing fitter's smaller training torque residual,
which uses measured corrected force rather than model-predicted gravity.

Additional offline physical-constrained fit: nonlinear least squares for
mass, SO(3) sensor rotation and force bias; then linear CoM/torque-bias fit
using predicted gravitational forces. Parameters fitted on training only.
No robust loss, residual cherry-picking or extra-validation tuning used.

Equivalent mass 3.123693 kg; sensor-frame equivalent CoM
[-76.846491,77.419259,67.082311] mm. Not flange/base coordinates and not
independently weighed mass or physically measured CoM; cable loads may be
absorbed into effective parameters.

| Evaluation | Force component RMS N | Max force vector N | Torque component RMS Nm | Max torque vector Nm |
|---|---:|---:|---:|---:|
| 9 training | .109594 | .278744 | .027563 | .075382 |
| 4 held-out angles | .111394 | .319299 | .024879 | .063670 |
| 6 later X repeat, 103020 | .187687 | .459302 | .034496 | .089125 |
| 6 later X repeat, 103844 | .189926 | .423354 | .030488 | .076732 |

RMS is across scalar components, not RMS vector norm. Vector maxima are
observed finite-sample maxima, not confidence bounds or workspace guarantees.
Original force direction/frame and rigid-tool assumptions retained. Only
static single-axis local +/-20 degree range and unchanged route-v2 studied;
no dynamic or full-workspace validity claimed. More held-out physical trials
are needed before enabling compensation or claiming a force-control accuracy.

Known-parameter synthetic test recovered mass, sensor rotation/bias and CoM,
with held-out forward force/torque residual <1e-6. That checks implementation,
not real-world model adequacy. Scripts reside in ~/.dsh-analysis/:
fit_relaxed_gravity_review.py and test_relaxed_gravity_review.py.

Practical interpretation: current data support investigating a roughly
0.5 N / 0.1 Nm *local static residual scale* candidate, not a 0.1 N accuracy
claim. Do not overwrite original rejected strict-screen result or auto-write
these equivalent parameters as controller payload settings.
