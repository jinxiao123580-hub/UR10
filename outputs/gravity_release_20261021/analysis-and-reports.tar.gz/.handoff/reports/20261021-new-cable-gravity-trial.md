# New cable-route local gravity trial — 2026-10-21

User confirmed no contact/held object, clearance, supervision/E-stop and
single-axis +/-10 degree low-speed motion. No bias, tare, payload, or active
gravity-compensation configuration changed.

## Repeat trial after user's request

Under `local-new-cable-20261021/`, `repeat-x-minus5-out.json` and
`repeat-x-minus5-back.json` record a successful repeat: return force norm
0.227341 N, torque norm 0.020649 Nm, 0.020714 mm / 0.009524 degrees.
The earlier 0.082525 Nm torque-return difference did not repeat this time;
this is evidence of variability, not proof its cause has been removed.

`repeat-y-plus5-out.json` / `repeat-y-plus5-back.json`: return force norm
0.060240 N, torque norm 0.006584 Nm, 0.094627 mm / 0.008265 degrees.
`repeat-y-minus5-out.json` / `repeat-y-minus5-back.json`: return force norm
0.055864 N, torque norm 0.018694 Nm, 0.054263 mm / 0.004273 degrees.
Both passed unchanged 0.3 N, 0.05 Nm, 0.5 mm, 0.1 degree trial gates.
Arm returned after each successful excursion. No new gravity model activated.
These trial gates are collection repeatability checks, not a validated
writing-force accuracy specification. Remaining orientation coverage and
held-out validation are still required.

Evidence root: `/home/jx/UR10/outputs/ft_calibration/`.

- `new-cable-static-20261021.json`: 3 static 3-second windows passed.
- `new-cable-x10-preflight-20261021.json`: path dry-run passed.
- `new-cable-x10-out-20261021.json` and `new-cable-x10-return-20261021.json`:
  actual return 0.033380 mm / 0.004656 degrees; return-minus-start wrench
  [0.006284,0.093206,0.174626,0.013876,0.005671,-0.012868] N/Nm.
  Force-vector difference norm 0.198043 N.
- `local-new-cable-20261021/session.json`: X +5 return force norm 0.149014 N,
  torque norm 0.013422 Nm, pose error 0.049884 mm / 0.003506 degrees.
  X -5 return force norm 0.257104 N, torque norm 0.082525 Nm, pose error
  0.053300 mm / 0.008704 degrees. Collection stopped at the configured
  torque-return limit 0.05 Nm (force-return limit 0.3 N). Remaining Y,
  negative-X10 and +/-7.5 held-out poses were NOT executed.
- `local-new-cable-20261021/post-return-static.json`: six additional static
  windows passed, but did not restore the pre-X-5 baseline. First/last
  force delta norms 0.233759 / 0.269532 N; torque delta norms
  0.071867 / 0.068070 Nm. Across-window torque-mean ranges only
  [0.003358,0.002054,0.001033] Nm. Force-mean ranges
  [0.013557,0.005641,0.053318] N.

Conclusion: initial repeatability varies by rotation direction. A persistent
non-contact baseline difference remains after a negative-X excursion. This
is compatible with cable/mounting/history effects, not a unique causal
identification. Current trial did not acquire a full fit/holdout dataset;
no new usable gravity model was produced or activated. Static raw Fz near
70 N is NOT the inferred tool weight, since bias and frame/sign are not yet
identified. Further on-site checks of tool mounting, cable clamps and
unobserved contact plus repeatability tests are needed before resuming.
