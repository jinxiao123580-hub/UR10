# Cable route v2, X-only refill and repeat comparison

Six planned X-axis out/absolute-return trials completed. Fixed 10 s dwell,
no tare, no compensation activation, installation label cable-route-v2-20261021.

Refill session:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-103020/session.json`

Comparator same-route session:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-101644/session.json`

Continuous paired gzip dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-103019-791152-gravity-cable-v2-x-refill/`

| Angle | Prior force N | New force N | Prior torque Nm | New torque Nm | New acceptance |
|---|---:|---:|---:|---:|---|
| -15 | .469219 | .136221 | .076480 | .025248 | pass |
| +15 | .137172 | .350433 | .024998 | .068062 | reject |
| -20 | .321522 | .349134 | .082385 | .069703 | reject |
| +20 | .297360 | .464045 | .063251 | .078911 | reject |
| -12 held out | .327517 | .274132 | .058466 | .062721 | reject |
| +12 held out | .358835 | .290839 | .051240 | .055487 | reject |

Max global-home return discrepancy .057004 mm / .007169 degrees. All
commanded pairs returned successfully; rejected status concerns baseline
repeatability, not a missed endpoint. Held-out +/-12 forces meet 0.3 N but
torque norms exceed 0.05 Nm. One accepted new training orientation; neither
new X holdout passed. Cannot claim successful gravity validation or choose
whichever repeat happens to pass while ignoring failed repetitions.

62,929 force and 39,262 UR samples, recorder errors [], child exit 0,
metadata recorded. Collection complete, calibration not complete. Existing
candidate remains rejected; no new candidate was fitted from mixed repeats.

Signs of return variation are not deterministically tied to positive/negative
X: -15 improved while +15 worsened. Additional identical pose samples alone
do not remove history-dependent load. Further load-path/fixture checks or
a separately validated state/history-dependent disturbance model are needed.
