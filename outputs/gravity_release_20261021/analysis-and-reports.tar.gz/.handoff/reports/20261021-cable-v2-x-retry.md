# Cable v2 X retry, unchanged conditions

First launch stopped before motion because a new ROS subscriber's first
1 s window received zero messages; parallel recorder still received both
streams. Added bounded 5 s subscriber-readiness wait, without weakening
source timestamp, rate, finite-value, uniqueness or noise checks. Delayed
discovery and missing-data behavior tested without hardware.

Complete retry session:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-103844/session.json`

Full-rate local paired gzip dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-103843-803855-gravity-cable-v2-x-retry-ddsfix/`

| X angle | Return force norm N | Return torque norm Nm | Acceptance |
|---|---:|---:|---|
| -15 | .129921 | .012064 | pass |
| +15 | .317142 | .064523 | reject |
| -20 | .358031 | .068602 | reject |
| +20 | .310842 | .067818 | reject |
| -12 held out | .244250 | .051484 | reject |
| +12 held out | .145341 | .043382 | pass |

All six out/absolute-return motions completed; robot returned. Maximum
global-home pose difference .110981 mm / .010807 degrees. Fixed 10 s dwell,
same route-v2 label, no tare or compensation activation. 62,731 force and
39,175 UR rows, recorder errors [], child exit 0. Collection complete only.

Compared with the immediately previous refill, X-15 passes again and +15,
both 20-degree orientations fail again. +12 improved and passed; -12 torque
is near but still above 0.05 Nm. Retain all repeats; do not replace failed
samples with selected passing ones to claim successful gravity validation.
Installation-specific X-axis baseline repeatability remains inadequate for
the planned full gravity model. No active model updated.
