# Reversed negative-axis order comparison

Local-only paired continuous acquisition. No tare or model activation.
Both commanded rotations returned to the fixed measured reference and passed.

Evidence for reversed X-20 then Y-20:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-095522/session.json`

Paired gzip dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-095521-520244-gravity-reverse-negative20/`

Comparator Y-20 then X-20:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-095209/session.json`

| Order | Direction | Return force norm N | Return torque norm Nm |
|---|---|---:|---:|
| Y then X | Y-20 | 0.086820 | 0.011885 |
| Y then X | X-20 | 0.400699 | 0.093105 |
| X then Y | X-20 | 0.038228 | 0.028111 |
| X then Y | Y-20 | 0.053937 | 0.012571 |

Reversed-order local return poses: X 0.050967 mm / 0.004348 deg;
Y 0.009410 mm / 0.004899 deg. Max global-home position discrepancy
0.087826 mm. Reversed session status completed_collection_not_calibrated,
child exit 0; recorder errors []. 20,276 force and 12,674 UR rows preserved.

Interpretation: X-20 is not intrinsically non-repeatable in every trial.
Changing sequence coincided with a much smaller returned wrench difference.
Mechanical history (cable/mount stress or hysteresis) is consistent with this;
it is not a proven unique cause. Only one AB and one BA sequence have been
compared, with different prior histories and elapsed time. No controlled
reset to the same mechanical state or external force/temperature reference
was obtained. Need repeated ABBA/counterbalanced trials with stationary
controls to separate sequence effects, relaxation and drift. Do not claim
reordering alone permanently solves calibration or enables a global model.
