# Four-block counterbalanced order repeat (XY, YX, YX, XY)

All local only. Eight single-axis -20-degree out/absolute-return pairs
completed; all passed unchanged 0.3 N / 0.05 Nm and pose-return checks.
No sensor tare or active-model change. A later user-approved policy to retain
failed wrench trials and continue was prepared but not needed: the original
conservative process completed all trials; no continuation replay occurred.

Session:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-100058/session.json`

Paired gzip dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-100058-003725-gravity-order-abba/`

| Block | Order | X return force N | Y return force N | X torque Nm | Y torque Nm |
|---|---|---:|---:|---:|---:|
| 1 | XY | .124828 | .062682 | .025872 | .009571 |
| 2 | YX | .125365 | .129496 | .021914 | .006289 |
| 3 | YX | .049299 | .120763 | .014227 | .017006 |
| 4 | XY | .119755 | .087988 | .018281 | .011583 |

Mean force norm by axis/order (only two observations per cell):
X in XY .122292 N, X in YX .087332 N;
Y in XY .075335 N, Y in YX .125129 N.
Maximum global-reference pose discrepancies .066372 mm / .013030 degrees.
The earlier X-return .400699 N after Y was not reliably reproduced.

## Fixed waiting follow-up

Each pair had 10 s post-return dwell, no motion or tare. Last 2 s of each
dwell were averaged from paired force.csv.gz (400 samples each). Difference
to that trial's pre-out baseline, early versus late force-vector norms N:
1 X .1248 -> .1350; 2 Y .0627 -> .0632;
3 Y .1295 -> .0685; 4 X .1254 -> .0964;
5 Y .1208 -> .1207; 6 X .0493 -> .0686;
7 X .1198 -> .1303; 8 Y .0880 -> .1141.
Waiting reduced some differences but did not consistently drive all to zero.
Early torque norms vs late Nm:
1 .0259 -> .0210; 2 .0096 -> .0104; 3 .0063 -> .0078;
4 .0219 -> .0160; 5 .0170 -> .0174; 6 .0142 -> .0105;
7 .0183 -> .0113; 8 .0116 -> .0129.

## Data integrity

96,515 force rows, source-clock average 200 Hz, largest source interval
8.499 ms, no nonpositive source intervals. 60,316 UR rows, 125 Hz, max
controller-source interval 8 ms, no nonpositive intervals. Force interval
max alone cannot prove no individual force message was lost. Recorder
errors [], metadata recorded, child exit 0. No hardware clock sync claimed.

## Interpretation

Sequence/history remains a plausible contributor but reordering is not a
proven sufficient fix, and a deterministic bad-X-direction claim is not
supported. Fixed return reference and fixed waiting conditions produce good
local repeatability in this run; differences from earlier tests may also
involve mechanical conditioning, temperature, temporal drift, and random
variation. Two repeats per axis/order do not establish statistical causation.
This is a reproducibility diagnostic, not completed gravity mass/CoM fitting
or independent force-control accuracy validation.
