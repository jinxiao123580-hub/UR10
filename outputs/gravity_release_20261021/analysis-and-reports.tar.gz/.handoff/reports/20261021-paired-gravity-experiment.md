# Paired local gravity experiment — 2026-10-21

Local only; no upload, bias/tare or compensation installation.

Dataset directory:
`/home/jx/UR10/outputs/experiment_datasets/20261021-092515-699984-gravity-repeat-paired/`

Experiment session:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-092516/session.json`

Data acquisition succeeded over the recorded experiment interval:
- force.csv: 25,720 rows, source-clock average 200.0001 Hz,
  largest source gap 6.587 ms, no nonpositive source intervals.
- ur.csv: 16,066 rows, controller-clock average 125 Hz,
  largest source gap 8.000 ms, no nonpositive source intervals.
- Original UR frames retained as ur-frames.bin; experiment.log and markers.csv
  relate the stream to child process execution. Different source clocks are
  NOT hardware synchronized; receipt timestamps are also preserved.
- Metadata status recorded and no stream errors. Child exit code is 1:
  data completeness does NOT imply full experiment completion.

First round X-10/Y+10/Y-10 passed the unchanged return checks. Second-round
X-10 returned successfully, with local force change 0.096517 N and torque
0.036238 Nm, local pose difference 0.098631 mm / 0.011173 degrees. However,
its difference to the original long-session reference was 0.509388 mm /
0.108282 degrees, exceeding 0.5 mm / 0.1 degree global limits. Remaining
five pairs were cancelled; robot had already returned before this check.

Cause of global drift: relative out/inverse-return commands build on the
actual arrival rather than one immutable target. The trial runner and
single-step probe were updated afterward to use one successful first-out
JSON as the fixed absolute return reference throughout a NEW session.
Full model/IK checks and local +/-10 degree envelope remain. This correction
was not executed in this dataset; it must not be retroactively attributed.

Earlier temporary raw recorder had an API mismatch (RealtimeReader lacked
read()). Its force-only files remain partial and are not substitutes for
this paired dataset. Prior nine-pair statistics are separate experiments.
