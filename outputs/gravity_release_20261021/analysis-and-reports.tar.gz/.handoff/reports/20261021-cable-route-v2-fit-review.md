# Cable route v2: complete collection, rejected gravity model, load-path clue

New physical cable route explicitly confirmed for supervised single-axis
+/-20 degrees. No old-route samples mixed into fit. No tare or model enable.

Session: `/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-101644/session.json`

Gravity review: same directory `gravity-candidate-review.json`.
Diagnostic: same directory `return-load-path-diagnostic.json`.

Paired continuous gzip data:
`/home/jx/UR10/outputs/experiment_datasets/20261021-101643-171860-gravity-cable-route-v2-fit/`

All 12 planned poses completed, robot returned to fixed home. Maximum global
home discrepancy 0.094967 mm / 0.010733 degrees. Recorder 126,024 force and
78,723 UR rows, errors [], child exit 0. Completion means collection only.

| Axis/angle | Return force norm N | Return torque norm Nm | Collection acceptance |
|---|---:|---:|---|
| X+15 | .137172 | .024998 | pass |
| Y+15 | .060071 | .008277 | pass |
| X-15 | .469219 | .076480 | reject |
| Y-15 | .062533 | .012134 | pass |
| X+20 | .297360 | .063251 | reject |
| Y+20 | .032044 | .011735 | pass |
| X-20 | .321522 | .082385 | reject |
| Y-20 | .048666 | .012607 | pass |
| X+12 held out | .358835 | .051240 | reject |
| Y+12 held out | .048186 | .008957 | pass |
| X-12 held out | .327517 | .058466 | reject |
| Y-12 held out | .067295 | .007886 | pass |

Only five nonzero-angle training poses passed; adding the home gives six
training samples. Only two of the four held-out poses passed. Candidate
correctly rejected before mass/CoM fit, no new active model exists. X+15
improved versus route v1 (~.594 N / .106 Nm), but not all X directions did.

Exploratory diagnostic includes rejected trials specifically to study their
non-contact disturbance, not to pass them as gravity calibration. Fit
delta_tau = r cross delta_F using eight training-return wrench differences,
test on four held-out-return differences. Effective sensor-axis r is
[-.138160,.067795,-.162972] m; rank 3, condition 6.305. Training torque
component RMS .006876 Nm; held-out RMS .005386 Nm, versus held-out raw
torque-difference component RMS .022705 Nm. Held-out maximum residual-vector
norm .009797 Nm. This suggests a shared mechanical load-path contribution.

The effective lever is not a uniquely identified cable attachment coordinate.
Mount loading, sensor cross-coupling and drift are not independently ruled
out. This relation predicts torque GIVEN measured force difference, NOT
cable force from pose/history; it is not a usable non-contact compensation
model. Applying it indiscriminately during contact could remove real pen
contact load. Further controlled cable/fixture load-path checks and new
held-out gravity data are required for full variable-pose writing force use.
