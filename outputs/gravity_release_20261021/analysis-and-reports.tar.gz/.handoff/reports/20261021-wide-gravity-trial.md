# Expanded gravity calibration attempt and stationary follow-up

User explicitly authorized supervised low-speed single-axis +/-20 degrees.
The default probe envelope remains 10 degrees unless explicitly overridden.
All outputs local; no sensor tare, active-model change or upload.

## Expanded trial

Session: `/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-094545/session.json`

Raw paired dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-094544-879008-gravity-wide20-train-holdout/`

Planned training X/Y +/-15, +/-20; held-out X/Y +/-12. Only X+15 out and
absolute return were executed. Return force norm 0.608560 N, torque norm
0.117559 Nm, exceeding unchanged 0.3 N / 0.05 Nm collection gates. Local
return pose difference 0.043087 mm / 0.003415 degrees, global difference
0.048635 mm / 0.006695 degrees. All remaining poses cancelled after return.

Full-rate gzip dataset contains 8,269 force rows and 5,169 UR rows, no stream
errors, continuous mode with no idle pause. Child exited 1 because of trial
gate failure, not recording failure. This is not a completed calibration.

## Stationary recovery observation

Summary: `/home/jx/UR10/outputs/ft_calibration/new-cable-x15-relaxation-20261021.json`

Raw paired dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-094644-239516-gravity-wide15-relaxation/`

Eight 3-second windows all passed stationary checks. Relative to the
pre-X+15 baseline, first and last force-vector delta norms were 0.538083 /
0.537057 N; torque-vector norms 0.105393 / 0.101721 Nm. First follow-up force
window began 19.526 s after the original return sample ended. Last delta:
[-0.175796,0.402648,0.308870,0.071586,0.055991,-0.045690] N/Nm.

Across-window mean ranges were only [0.013914,0.020127,0.043588] N and
[0.003452,0.002258,0.001098] Nm. Thus baseline remained offset rather than
recovering to the original value during observation. Raw force 6,557 rows,
UR 4,034 rows. No robot motion was commanded during follow-up.

## Interpretation

Fixed-reference return works at X+15 too, but the original zero-load wrench
is not reproducible after this excursion. This cannot be explained by a
single rigid payload gravity plus fixed bias alone. Cable/mounting stress,
hysteresis, unnoticed contact and sensor drift are hypotheses, not uniquely
identified causes. Do not silently absorb the offset into mass/CoM or re-zero
at each orientation. A meaningful new gravity model requires resolving the
non-contact baseline instability or explicitly validating a limited-scope
combined disturbance model with independent held-out paths. No candidate
has been enabled; current installation/clearance should be checked on site.
