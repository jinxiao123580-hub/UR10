# Y-20 and X-20 directional trials

Evidence session:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-095209/session.json`

Continuous paired gzip dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-095208-187110-gravity-negative20-directions/`

Y-20 out and absolute return completed; return force delta norm 0.086820 N,
torque norm 0.011885 Nm, local pose discrepancy 0.059673 mm / 0.007277 deg.
Passed unchanged collection repeatability gates.

X-20 out and absolute return completed next; force delta norm 0.400699 N,
torque norm 0.093105 Nm, local pose discrepancy 0.034397 mm / 0.003656 deg.
Failed 0.3 N / 0.05 Nm gates after the return. No further motion.
Force XYZ delta [0.136398,-0.240518,-0.290011] N;
torque XYZ delta [-0.070162,-0.051805,0.032590] Nm.

20,374 force and 12,680 UR raw CSV rows recorded, no recorder errors.
Child exit 1 reflects final reproducibility-gate failure, not stream loss.
All local only, continuous recording, no tare or compensation activation.

Compared with Y+20 (0.318130 N / 0.050235 Nm in previous session), Y-20
was substantially more reproducible in this single comparison. X-20 also
changes baseline, so the effect is not exclusive to positive X. X+15 is
a different angle and must not be mislabeled X+20. Actual X+20 is untested.

Direction dependence is plausible but not uniquely causal: trials have
different starting wrench histories and fixed order. Repeat with reversed
order and stationary controls to distinguish cable history from drift or
other installation forces. Rigid-gravity-only model remains unvalidated.
