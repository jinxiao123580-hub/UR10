# Historical gravity/cable evidence audit — 2026-10-21

Read-only audit of existing records; no robot motion or calibration update.

## Supported observations

1. Static stability, not a universal noise floor:
   `/home/jx/UR10/outputs/ft_calibration/static-drift-20261012.json`
   contains 12 stationary windows spanning 72.195 seconds. Across-window
   mean-force peak-to-peak XYZ is [0.015344, 0.019597, 0.073704] N.
   These are ranges of window means, NOT raw sample ranges or standard
   deviations. Largest recorded force-message age is 6.818 ms. A second
   static session, `static-drift-new-pose-20261012.json`, has corresponding
   ranges [0.017585, 0.007991, 0.023573] N.

2. Post-excursion baseline does not always return:
   `/home/jx/UR10/outputs/ft_calibration/two-anchor-collection-retry-20261012.json`
   ended `stopped_on_error`, not a completed validated calibration.
   A-start sample versus final A_y-15_back leg actual controller poses differ
   by 0.026253 mm and 0.006873 degrees (SO(3) relative rotation, not rotvec
   subtraction). Four return-baseline retry diagnostics show force delta
   starting at [0.209,-0.3063,-0.3613] N, norm 0.517724 N, ending at
   [0.1998,-0.3034,-0.3001] N, norm 0.471202 N. Values in the diagnostics are
   rounded to four decimals. Waiting/recollecting did not restore baseline.
   Raw trace: `two-anchor-collection-retry-20261012.raw.csv` in same directory.
   Note: the recorded returned pose and force retry windows are not a new
   synchronized independent pose measurement for every retry.

3. Smaller, reasonably returned orientation excursions:
   `ros-x10-plus-20261012.json` raw_before compared with
   `ros-x10-return-20261012.json` raw_after: force delta
   [-0.03792,0.09030,0.15399] N; pose return discrepancy 0.042139 mm,
   0.006187 degrees. Corresponding Y pair (`ros-y10-plus`, `ros-y10-return`):
   [-0.04147,0.06249,0.14006] N, 0.030469 mm, 0.004991 degrees.
   Paths in both comparisons are under the same ft_calibration directory.
   These are rotation excursions, NOT same-orientation translation tests.

4. Historical model validation exists but is installation/scope specific:
   `fullrange-robust-validation-20260915.json`: saved aggregate force RMS
   0.374993 N, maximum absolute force component 0.976893 N; torque RMS
   0.049220 Nm. Saved acceptance passed with RMS limits 1 N / 0.1 Nm.
   Scope explicitly static, no contact, unchanged cable route. Do not equate
   this to current pen-installation validity, dynamic accuracy, independent
   global generalization, or a 0.1 N precision claim. Raw CSV accompanies it.

## Interpretation and limits

Supported: some non-contact return measurements differ more than the
stationary window-mean drift; constant tool gravity plus a single fixed bias
is insufficient to explain those sessions by itself. Path-dependent cable
loading is consistent with the observations. It is NOT uniquely proven:
mounting changes, temperature/bias drift, unobserved contact or other loads
were not independently eliminated in these records. No cable length,
clamp boundary orientation, shape or bending/torsion parameters are recorded
well enough to identify a two-end flexible cable model from this audit.
Oct-12 collection contains only 10 accepted samples and stopped early;
planned holdouts do not establish completed held-out validation.

Next evidence: repeat matched final q/pose approached along two directions,
interleave stationary controls, and compare same orientation at different
positions with documented unchanged cable routing. Then assess a bounded
workspace gravity-plus-residual model using held-out complete paths.
