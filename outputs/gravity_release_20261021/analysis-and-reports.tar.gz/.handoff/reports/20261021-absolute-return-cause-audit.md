# Fixed-reference repeat experiment: cause audit

Local only, 2026-10-21. All 9 prescribed pairs (3 directions x 3 repeats)
completed; no hardware tare, active compensation or payload change.

## Evidence

Session: `/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-093054/session.json`

Paired dataset: `/home/jx/UR10/outputs/experiment_datasets/20261021-093053-721706-gravity-absolute-return-repeat/`

Prior relative-return comparator:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-092516/session.json`

## Results

Fixed absolute return reference, maximum discrepancy to session home:
0.071431 mm / 0.007919 degrees. Prior relative-return session stopped at
0.509388 mm / 0.108282 degrees. These are controller-reported pose
comparisons, not externally measured absolute accuracy.

Return force-vector norms N (repeat 1, 2, 3):
- X -10: [0.060276, 0.164017, 0.170911]
- Y +10: [0.074463, 0.028507, 0.068327]
- Y -10: [0.141643, 0.115020, 0.227623]

Return torque-vector norms Nm:
- X -10: [0.017231, 0.045147, 0.041427]
- Y +10: [0.013762, 0.016380, 0.015944]
- Y -10: [0.032569, 0.029591, 0.042395]

At each excited pose, across-repeat componentwise mean-force ranges N:
- X -10: [0.056689, 0.024545, 0.071483]
- Y +10: [0.015451, 0.030449, 0.008600]
- Y -10: [0.047498, 0.006572, 0.056892]

At home, combining all pre-out and post-back window means, componentwise
force ranges [0.052066,0.174737,0.248264] N and torque ranges
[0.047263,0.018433,0.022512] Nm. Start-to-end force mean delta is
[0.012958,0.149782,0.166254] N over 286.491 seconds. Thus removing pose
accumulation did not eliminate force-baseline changes.

Y-10 return delta Fy is positive in all three repeats:
[0.11224,0.09179,0.15798] N; its torque delta Tx also consistently positive.
X-10 returns have negative delta Fy and Tx (especially repeats 2/3).
This directional pattern is compatible with mechanical history/cable loading;
sample size and measurement controls do not establish unique causation.

## Acquisition verification

57,931 force rows: source-clock average 200.00005 Hz, maximum source gap
6.556 ms, no nonpositive intervals.
36,162 UR rows: controller-clock average 125 Hz, maximum source gap 8 ms,
no nonpositive intervals. Metadata recorded, child exit 0, stream errors [].
Raw frames, CSVs, receipt/source timestamps and experiment logs retained.
Hardware synchronization is not claimed.

## Causal conclusions

Supported: changing from incremental inverse rotations to one fixed absolute
return target removed the observed cumulative return-pose failure in this
trial. The old failure should not be directly assigned to DH or hand-eye
calibration. Changed controller targets explain the eliminated accumulation.

Remaining: non-contact wrench varies even with closely repeated reported
pose. Cable/mount hysteresis or stress relaxation, sensor drift/temperature,
and limited settling/averaging remain plausible contributors. Raw static
Fz standard deviations in individual windows range roughly 0.02--0.15 N;
do not equate all return differences to a new physical cable force.
No controlled cable-free comparison, clamp-force measurement, temperature
trace or independent external load reference was acquired.

Next discriminating experiment: same final pose, controlled approach direction,
record 10--20 seconds after each return with no motion; compare early/late
means and interleave equal-duration no-motion controls. Preserve original
sensor bias, cable routing and hardware installation. Full gravity fitting
still requires sufficient orientation coverage and held-out validation.
