# Other-direction 20-degree diagnostic

User requested other single-axis 20-degree directions, within previously
confirmed +/-20 degree supervised envelope. Continuous local paired capture.

Planned order Y+20, Y-20, X-20, starting with the direction most repeatable
at 10 degrees. Only Y+20 out/absolute return executed; remaining cancelled
by unchanged return reproducibility gate.

Session:
`/home/jx/UR10/outputs/ft_calibration/repeat-other-directions-20261021-094903/session.json`

Paired full-rate gzip dataset:
`/home/jx/UR10/outputs/experiment_datasets/20261021-094903-306983-gravity-other20-directions/`

Y+20 return-minus-pre force XYZ:
[0.175728,-0.190273,-0.184723] N; norm 0.318130 N (limit 0.3 N).
Torque XYZ [-0.038812,-0.028706,0.013898] Nm; norm 0.050235 Nm
(limit 0.05 Nm). Local return pose 0.040551 mm / 0.006313 degrees;
global return 0.064386 mm / 0.007845 degrees. Robot returned before the
gate stopped subsequent trials. No model/configuration/tare changed.

10,233 force and 6,396 UR samples retained, no recorder errors; child
exit 1 is the diagnostic gate failure, not missing raw data.

Compared with the earlier X+15 result (0.608560 N / 0.117559 Nm), Y+20
showed a smaller but still non-reproducible baseline. This disproves an
exclusive claim that baseline changes occur only along positive X. It does
not prove all directions behave identically, nor isolate cable causation.
Y-20 and X-20 have not been measured in this diagnostic session.
